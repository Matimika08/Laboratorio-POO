
public class Triangulo extends Forma {
	private Double base;
	private Double Altura;
	
	
	public Double getBase() {
		return base;
	}
	public void setBase(Double base) {
		this.base = base;
	}
	public Double getAltura() {
		return Altura;
	}
	public void setAltura(Double altura) {
		Altura = altura;
	}
	
	

}
